'use client'

import FileEngineApp from '@/components/FileEngineAppV2'

export default function DashboardPage() {
  return <FileEngineApp />
}
