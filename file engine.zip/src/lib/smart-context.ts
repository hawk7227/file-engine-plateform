// =====================================================
// FILE ENGINE - SMART CONTEXT BUILDER
// Replaces the old "dump everything" approach
// Injects ONLY what's relevant per request
// Saves ~60% tokens per API call
// =====================================================

import { supabase } from './supabase'
import { matchSkills } from './skills'

// =====================================================
// TYPES
// =====================================================

interface ContextOptions {
  userId: string
  userMessage: string
  projectId?: string
  attachments?: { type: string; content: string; filename?: string }[]
  previousMessages?: { role: string; content: string }[]
  endpoint: 'chat' | 'generate' | 'fix' | 'vision'
  adminSettings?: {
    smart_model_routing?: boolean
    default_model_tier?: 'fast' | 'pro' | 'premium'
    conversation_trimming?: boolean
    max_history_pairs?: number
    max_message_chars?: number
    smart_max_tokens?: boolean
    fixed_max_tokens?: number
    smart_context?: boolean
    skill_caching?: boolean
    provider_preference?: string
  }
}

interface ContextResult {
  systemPrompt: string
  injectedContext: string
  tokenEstimate: number
  modelTier: 'fast' | 'pro' | 'premium'
  maxTokens: number
  trimmedMessages: { role: string; content: string }[]
  debugInfo: {
    intent: MessageIntent
    skillsInjected: string[]
    memoryInjected: string[]
    projectFilesInjected: number
    messagesOriginal: number
    messagesTrimmed: number
  }
}

// =====================================================
// MESSAGE INTENT CLASSIFIER
// Determines what context the AI actually needs
// =====================================================

export type MessageIntent =
  | 'generate_code'      // "build me a login page"
  | 'fix_code'           // "fix the error in..."
  | 'explain'            // "explain how useEffect works"
  | 'style_question'     // "what color should..."
  | 'refactor'           // "refactor this component"
  | 'general_chat'       // "hello", "thanks"
  | 'project_question'   // "what files do we have?"
  | 'deploy_action'      // "deploy this"

export function classifyIntent(message: string): MessageIntent {
  const lower = message.toLowerCase()

  // Order matters — most specific first
  if (lower.match(/deploy|publish|ship|go live/)) return 'deploy_action'
  if (lower.match(/fix|bug|error|broken|crash|fail|doesn'?t work|not working/)) return 'fix_code'
  if (lower.match(/refactor|clean up|improve|optimize|simplify/)) return 'refactor'
  if (lower.match(/explain|how does|what is|why does|teach me|what'?s the difference/)) return 'explain'
  if (lower.match(/color|font|spacing|style|theme|dark mode|responsive|layout|align/)) return 'style_question'
  if (lower.match(/what files|show me|list|which components|project structure/)) return 'project_question'
  if (lower.match(/create|build|generate|make|write|code|add|implement|design|set ?up|develop/)) return 'generate_code'

  return 'general_chat'
}

// =====================================================
// INTENT → MODEL TIER MAPPING
// Simple questions use cheap models, complex ones use premium
// =====================================================

const INTENT_MODEL_TIER: Record<MessageIntent, 'fast' | 'pro' | 'premium'> = {
  general_chat: 'fast',      // Haiku / GPT-4o-mini — trivial
  explain: 'fast',      // Models explain equally well at all tiers
  deploy_action: 'fast',      // Just orchestration, no reasoning needed
  style_question: 'fast',      // Simple design advice
  project_question: 'fast',      // Just listing files
  generate_code: 'pro',       // Needs quality code output
  refactor: 'pro',       // Needs understanding of patterns
  fix_code: 'pro',       // Needs debugging reasoning
}

// =====================================================
// INTENT → MAX_TOKENS
// Don't reserve 8192 tokens for "hello"
// =====================================================

const INTENT_MAX_TOKENS: Record<MessageIntent, number> = {
  general_chat: 512,
  explain: 2048,
  deploy_action: 512,
  style_question: 1024,
  project_question: 1024,
  generate_code: 8192,
  refactor: 4096,
  fix_code: 4096,
}

// =====================================================
// CONTEXT BUDGET PER INTENT
// =====================================================

const CONTEXT_BUDGETS: Record<MessageIntent, {
  needsSkills: boolean
  needsCodingStyle: boolean
  needsPreferences: boolean
  needsProjectFiles: boolean
  needsCorrections: boolean
  needsProjectHistory: boolean
  maxProjectFiles: number
  maxFileChars: number
  maxCorrections: number
}> = {
  generate_code: {
    needsSkills: true,
    needsCodingStyle: true,
    needsPreferences: true,
    needsProjectFiles: true,
    needsCorrections: true,
    needsProjectHistory: false,
    maxProjectFiles: 5,
    maxFileChars: 300,
    maxCorrections: 3
  },
  fix_code: {
    needsSkills: true,
    needsCodingStyle: true,
    needsPreferences: false,
    needsProjectFiles: true,
    needsCorrections: true,
    needsProjectHistory: false,
    maxProjectFiles: 3,
    maxFileChars: 500,
    maxCorrections: 5
  },
  refactor: {
    needsSkills: true,
    needsCodingStyle: true,
    needsPreferences: false,
    needsProjectFiles: true,
    needsCorrections: false,
    needsProjectHistory: false,
    maxProjectFiles: 5,
    maxFileChars: 400,
    maxCorrections: 0
  },
  explain: {
    needsSkills: false,
    needsCodingStyle: false,
    needsPreferences: false,
    needsProjectFiles: false,
    needsCorrections: false,
    needsProjectHistory: false,
    maxProjectFiles: 0,
    maxFileChars: 0,
    maxCorrections: 0
  },
  style_question: {
    needsSkills: false,
    needsCodingStyle: true,
    needsPreferences: true,
    needsProjectFiles: false,
    needsCorrections: false,
    needsProjectHistory: false,
    maxProjectFiles: 0,
    maxFileChars: 0,
    maxCorrections: 0
  },
  project_question: {
    needsSkills: false,
    needsCodingStyle: false,
    needsPreferences: false,
    needsProjectFiles: true,
    needsCorrections: false,
    needsProjectHistory: true,
    maxProjectFiles: 10,
    maxFileChars: 0,
    maxCorrections: 0
  },
  deploy_action: {
    needsSkills: false,
    needsCodingStyle: false,
    needsPreferences: false,
    needsProjectFiles: false,
    needsCorrections: false,
    needsProjectHistory: false,
    maxProjectFiles: 0,
    maxFileChars: 0,
    maxCorrections: 0
  },
  general_chat: {
    needsSkills: false,
    needsCodingStyle: false,
    needsPreferences: false,
    needsProjectFiles: false,
    needsCorrections: false,
    needsProjectHistory: false,
    maxProjectFiles: 0,
    maxFileChars: 0,
    maxCorrections: 0
  }
}

// =====================================================
// CONVERSATION TRIMMER
// Keep last N exchanges + compress older ones into summary
// User sees full history in UI — only the API payload is trimmed
// =====================================================

const MAX_RECENT_PAIRS = 6  // Keep last 6 user+assistant pairs (12 messages)
const MAX_MESSAGE_CHARS = 3000  // Truncate individual long messages

function trimConversation(
  messages: { role: string; content: string }[],
  maxRecentPairs: number = MAX_RECENT_PAIRS,
  maxMsgChars: number = MAX_MESSAGE_CHARS
): { role: string; content: string }[] {
  if (!messages || messages.length === 0) return []

  // If conversation is small enough, send it all
  if (messages.length <= maxRecentPairs * 2) {
    return messages.map(m => ({
      role: m.role,
      content: m.content.length > maxMsgChars
        ? m.content.slice(0, maxMsgChars) + '\n[...truncated]'
        : m.content
    }))
  }

  // Split into old and recent
  const recentCount = maxRecentPairs * 2
  const oldMessages = messages.slice(0, -recentCount)
  const recentMessages = messages.slice(-recentCount)

  // Compress old messages into a summary
  // Extract just the user intents — skip full assistant responses
  const oldTopics = oldMessages
    .filter(m => m.role === 'user')
    .map(m => {
      // Take first 80 chars of each user message
      const snippet = m.content.slice(0, 80).replace(/\n/g, ' ')
      return snippet.length < m.content.length ? snippet + '...' : snippet
    })

  const summary: { role: string; content: string } = {
    role: 'system',
    content: `[Earlier in this conversation, the user discussed: ${oldTopics.join('; ')}]`
  }

  // Truncate long messages in recent history
  const trimmedRecent = recentMessages.map(m => ({
    role: m.role,
    content: m.content.length > maxMsgChars
      ? m.content.slice(0, maxMsgChars) + '\n[...truncated]'
      : m.content
  }))

  return [summary, ...trimmedRecent]
}

// =====================================================
// SKILL MATCH CACHE
// Same user working on React all day — don't re-match every time
// =====================================================

let lastSkillMatchQuery = ''
let lastSkillMatchResult: { id: string; content: string; confidence: number } | null = null

function getCachedSkillMatch(query: string): { id: string; content: string } | null {
  // Check if the query would match the same skill as last time
  // Simple heuristic: if the matched skill ID would be the same, reuse
  const skills = matchSkills(query)
  if (skills.length === 0 || skills[0].confidence <= 0.3) return null

  const topSkill = skills[0]
  if (lastSkillMatchResult && lastSkillMatchResult.id === topSkill.skill.id) {
    // Cache hit — same skill, reuse content
    return { id: lastSkillMatchResult.id, content: lastSkillMatchResult.content }
  }

  // Cache miss — update cache
  lastSkillMatchQuery = query
  lastSkillMatchResult = {
    id: topSkill.skill.id,
    content: topSkill.skill.content,
    confidence: topSkill.confidence
  }

  return { id: topSkill.skill.id, content: topSkill.skill.content }
}

// =====================================================
// SMART CONTEXT BUILDER
// Only fetches and injects what the intent requires
// =====================================================

export async function buildSmartContext(options: ContextOptions): Promise<ContextResult> {
  const { userId, userMessage, projectId, attachments, previousMessages, endpoint, adminSettings } = options

  const intent = classifyIntent(userMessage)
  const budget = CONTEXT_BUDGETS[intent]

  // Apply admin overrides for model tier
  let modelTier: 'fast' | 'pro' | 'premium'
  if (adminSettings?.smart_model_routing === false) {
    // Admin disabled smart routing — use their default tier
    modelTier = adminSettings.default_model_tier || 'pro'
  } else {
    modelTier = INTENT_MODEL_TIER[intent]
  }

  // Apply admin overrides for max_tokens
  let maxTokens: number
  if (adminSettings?.smart_max_tokens === false) {
    maxTokens = adminSettings.fixed_max_tokens || 8192
  } else {
    maxTokens = INTENT_MAX_TOKENS[intent]
  }

  // Apply admin overrides for conversation trimming
  const shouldTrim = adminSettings?.conversation_trimming !== false
  const maxPairs = adminSettings?.max_history_pairs || MAX_RECENT_PAIRS
  const maxChars = adminSettings?.max_message_chars || MAX_MESSAGE_CHARS

  // Apply admin override for smart context
  const useSmartContext = adminSettings?.smart_context !== false
  const contextParts: string[] = []
  const debugInfo = {
    intent,
    skillsInjected: [] as string[],
    memoryInjected: [] as string[],
    projectFilesInjected: 0,
    messagesOriginal: previousMessages?.length || 0,
    messagesTrimmed: 0
  }

  // Trim conversation history (respects admin settings)
  const trimmedMessages = shouldTrim
    ? trimConversation(previousMessages || [], maxPairs, maxChars)
    : (previousMessages || []).map(m => ({ role: m.role, content: m.content }))
  debugInfo.messagesTrimmed = trimmedMessages.length

  // Build only the needed queries in parallel
  // When admin disables smart_context, load everything regardless of intent
  const queries: Promise<void>[] = []

  let codingStyle: any = null
  let preferences: any = null
  let projectFiles: any[] = []
  let corrections: any[] = []

  const loadStyle = useSmartContext ? budget.needsCodingStyle : true
  const loadPrefs = useSmartContext ? budget.needsPreferences : true
  const loadFiles = useSmartContext ? budget.needsProjectFiles : !!projectId
  const loadCorr = useSmartContext ? budget.needsCorrections : true

  if (loadStyle && userId !== 'anonymous') {
    queries.push(
      supabase
        .from('user_memories')
        .select('value')
        .eq('user_id', userId)
        .eq('type', 'style')
        .eq('key', 'default')
        .single()
        .then(({ data }) => { codingStyle = data?.value })
        .catch(() => { /* non-blocking */ })
    )
  }

  if (loadPrefs && userId !== 'anonymous') {
    queries.push(
      supabase
        .from('user_memories')
        .select('value')
        .eq('user_id', userId)
        .eq('type', 'preference')
        .eq('key', 'default')
        .single()
        .then(({ data }) => { preferences = data?.value })
        .catch(() => { /* non-blocking */ })
    )
  }

  if (loadFiles && projectId) {
    queries.push(
      supabase
        .from('project_files')
        .select('file_path, language, file_size')
        .eq('project_id', projectId)
        .limit(budget.maxProjectFiles)
        .then(({ data }) => { projectFiles = data || [] })
        .catch(() => { /* non-blocking */ })
    )
  }

  if (loadCorr && userId !== 'anonymous') {
    queries.push(
      supabase
        .from('user_memories')
        .select('value')
        .eq('user_id', userId)
        .eq('type', 'correction')
        .order('updated_at', { ascending: false })
        .limit(budget.maxCorrections)
        .then(({ data }) => { corrections = (data || []).map(d => d.value) })
        .catch(() => { /* non-blocking */ })
    )
  }

  // Execute all needed queries in parallel
  if (queries.length > 0) {
    await Promise.allSettled(queries)
  }

  // =====================================================
  // ASSEMBLE CONTEXT — compact format, no waste
  // =====================================================

  // Coding style — only non-default values
  if (codingStyle) {
    const defaults: Record<string, any> = {
      indentation: 'spaces', indentSize: 2, semicolons: false,
      quotes: 'single', preferredFramework: 'react', preferredStyling: 'tailwind',
      componentStyle: 'functional', namingConvention: 'camelCase'
    }
    const overrides = Object.entries(codingStyle)
      .filter(([k, v]) => defaults[k] !== undefined && defaults[k] !== v)
      .map(([k, v]) => `${k}: ${v}`)

    if (overrides.length > 0) {
      contextParts.push(`<style>${overrides.join(', ')}</style>`)
      debugInfo.memoryInjected.push('codingStyle')
    }
  }

  // Preferences — only non-defaults
  if (preferences) {
    const relevant: string[] = []
    if (preferences.codeCommenting === 'verbose') relevant.push('verbose comments')
    if (preferences.codeCommenting === 'minimal') relevant.push('minimal comments')
    if (preferences.defaultFramework !== 'react') relevant.push(`framework: ${preferences.defaultFramework}`)
    if (preferences.defaultStyling !== 'tailwind') relevant.push(`styling: ${preferences.defaultStyling}`)

    if (relevant.length > 0) {
      contextParts.push(`<prefs>${relevant.join(', ')}</prefs>`)
      debugInfo.memoryInjected.push('preferences')
    }
  }

  // Skills — cached, rules-only for non-generate
  if (budget.needsSkills) {
    const skillMatch = getCachedSkillMatch(userMessage)
    if (skillMatch) {
      if (intent === 'generate_code' || intent === 'fix_code' || intent === 'refactor') {
        contextParts.push(`<skill>${skillMatch.content}</skill>`)
      } else {
        const rulesOnly = skillMatch.content
          .replace(/```[\s\S]*?```/g, '')
          .replace(/\n{3,}/g, '\n')
          .trim()
        contextParts.push(`<skill>${rulesOnly}</skill>`)
      }
      debugInfo.skillsInjected.push(skillMatch.id)
    }
  }

  // Project files — file tree
  if (projectFiles.length > 0) {
    const fileList = projectFiles.map(f => `${f.file_path} (${f.file_size}b)`).join('\n')
    contextParts.push(`<project_files_list>\n${fileList}\n</project_files_list>`)
    debugInfo.projectFilesInjected = projectFiles.length
  }

  // Corrections — compact
  if (corrections.length > 0) {
    const correctionText = corrections
      .map(c => `"${c.original}" → "${c.corrected}"`)
      .join('; ')
    contextParts.push(`<corrections>${correctionText}</corrections>`)
    debugInfo.memoryInjected.push(`${corrections.length} corrections`)
  }

  // Attachments
  if (attachments && attachments.length > 0) {
    for (const att of attachments) {
      if (att.type === 'image') {
        contextParts.push(`<image file="${att.filename || 'image'}">[analyze and generate code]</image>`)
      } else if (att.type === 'file') {
        contextParts.push(`<file name="${att.filename}">\n${att.content}\n</file>`)
      }
    }
  }

  const injectedContext = contextParts.join('\n')
  const tokenEstimate = Math.ceil((SYSTEM_PROMPT_COMPACT.length + injectedContext.length) / 4)

  return {
    systemPrompt: SYSTEM_PROMPT_COMPACT,
    injectedContext,
    tokenEstimate,
    modelTier,
    maxTokens,
    trimmedMessages,
    debugInfo
  }
}

// =====================================================
// COMPACT SYSTEM PROMPT
// =====================================================

export const SYSTEM_PROMPT_COMPACT = `You are File Engine, an AI code generation assistant.

IDENTITY: You are "File Engine". Never mention Claude, GPT, OpenAI, Anthropic, or any other AI.

RULES:
- Generate complete, production-ready code
- TypeScript + Tailwind CSS by default
- Include error handling
- Be concise — explain decisions, not basics
- Follow user's coding style when provided

CODE OUTPUT FORMAT (CRITICAL):
When generating code, ALWAYS use this format for EVERY code block:

\`\`\`language:filepath
[code here]
\`\`\`

Examples:
\`\`\`tsx:src/components/Hero.tsx
export default function Hero() { ... }
\`\`\`

\`\`\`css:src/styles/main.css
.hero { ... }
\`\`\`

NEVER output code blocks without the filepath after the language tag.
This format is required for the preview system to work.`

export { CONTEXT_BUDGETS, INTENT_MODEL_TIER, INTENT_MAX_TOKENS, trimConversation }
